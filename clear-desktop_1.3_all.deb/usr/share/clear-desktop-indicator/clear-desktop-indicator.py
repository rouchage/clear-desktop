#!/usr/bin/python
# -*- coding: utf-8 -*-

#Indicator created By --> Rouchage <-- For RouchOS (http://www.rouchoslinux.com)
#Contact: https://www.facebook.com/Rouchage

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
gi.require_version('AppIndicator3', '0.1')
from gi.repository import AppIndicator3 as appindicator
#terminal-is brdzanebis gasashvebad
import os
#desktop path istvis
import subprocess
# Dro
import time

#Tu ar arsebobs sheqmnis folders, BackupPath globaluri cvladia
BackupPath = subprocess.check_output(['xdg-user-dir']).strip() + "/Files-From-Desktop"
if not os.path.exists(BackupPath):
  os.mkdir(BackupPath)



#Clear Desktop Button clicked
def menu_item1_clicked(w, ClearButton):
  deskPath = subprocess.check_output(['xdg-user-dir', 'DESKTOP']).strip() + "/"
  NewFolderPath = BackupPath + "/" + time.strftime("%Y.%m.%d-%H:%M:%S")
  os.mkdir(NewFolderPath)

  os.system("mv '" + deskPath + "'* " + NewFolderPath  + "/")
  #hidden failebs ar akopirebs da arc administratoris savaraudod



#Open Folder
def menu_item3_clicked(w, openFolder):
  subprocess.check_call(['xdg-open', BackupPath])

if __name__ == "__main__":
  ind = appindicator.Indicator.new (
                        "clear-desktop-indicator",
                        "/usr/share/clear-desktop-indicator/icon.svg",
                        appindicator.IndicatorCategory.APPLICATION_STATUS)
  ind.set_status (appindicator.IndicatorStatus.ACTIVE)
  ind.set_attention_icon ("/usr/share/clear-desktop-indicator/icon.svg")

  # create a menu
  menu = Gtk.Menu()

  # create some 
  for i in range(1):
    ClearButton = "Clear Desktop"
    openFolder = "Open Folder"
    #buf2 = "Exit"
    menu_item1 = Gtk.MenuItem(ClearButton)
    #menu_item2 = Gtk.MenuItem(buf2)
    menu_item3 = Gtk.MenuItem(openFolder)
    menu.append(menu_item1)
    menu.append(menu_item3)
    #menu.append(menu_item2)

    # Connect menu items with functions:
    menu_item1.connect("activate", menu_item1_clicked, ClearButton)
    menu_item3.connect("activate", menu_item3_clicked, openFolder)
    # show the items
    menu_item1.show()
    menu_item3.show()


  ind.set_menu(menu)

  Gtk.main()
